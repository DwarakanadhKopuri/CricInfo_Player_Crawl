# cricinfo-stats-scraper
## Scrape stats of a particular player from ESPN Cricinfo and store them in an Excel file
This notebook scrapes the ESPN Crincinfo website for Stats of a particular player and stores them in an excel file.
Currently it works only for Batsman but can be easily modified to suit the needs of bowlers as well.

# Steps to get started
1. Get the link to the stats of a particular player from Cricnfo.
![Start](https://i.imgur.com/d0HgLX0.png)
2. Replace the variable "url" with the link in the IPYNB Notebook.
![Start](https://i.imgur.com/pePzx8v.png)
3. Set the name of the .xlsx file in the IPYNB notebook.
![Start](https://i.imgur.com/13zPw0U.png)

